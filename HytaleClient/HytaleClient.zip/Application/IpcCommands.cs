﻿using System;

namespace HytaleClient.Application
{
	// Token: 0x02000BEB RID: 3051
	public static class IpcCommands
	{
		// Token: 0x04003C6D RID: 15469
		public const string OpenEditor = "OpenEditor";
	}
}
