﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020006D1 RID: 1745
	public struct AddNotifyClientIntegrityViolatedOptions
	{
	}
}
