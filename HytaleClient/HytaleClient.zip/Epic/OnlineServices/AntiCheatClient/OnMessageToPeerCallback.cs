﻿using System;
using Epic.OnlineServices.AntiCheatCommon;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020006E8 RID: 1768
	// (Invoke) Token: 0x06002DA8 RID: 11688
	public delegate void OnMessageToPeerCallback(ref OnMessageToClientCallbackInfo data);
}
