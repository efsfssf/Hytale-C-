﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020006D3 RID: 1747
	public struct AddNotifyMessageToPeerOptions
	{
	}
}
