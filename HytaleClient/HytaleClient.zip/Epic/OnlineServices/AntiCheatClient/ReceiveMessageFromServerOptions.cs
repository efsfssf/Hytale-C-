﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020006F8 RID: 1784
	public struct ReceiveMessageFromServerOptions
	{
		// Token: 0x17000DA7 RID: 3495
		// (get) Token: 0x06002DEE RID: 11758 RVA: 0x00043CCE File Offset: 0x00041ECE
		// (set) Token: 0x06002DEF RID: 11759 RVA: 0x00043CD6 File Offset: 0x00041ED6
		public ArraySegment<byte> Data { get; set; }
	}
}
