﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020006E4 RID: 1764
	// (Invoke) Token: 0x06002D8D RID: 11661
	public delegate void OnClientIntegrityViolatedCallback(ref OnClientIntegrityViolatedCallbackInfo data);
}
