﻿using System;
using Epic.OnlineServices.AntiCheatCommon;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020006EE RID: 1774
	// (Invoke) Token: 0x06002DC7 RID: 11719
	public delegate void OnPeerActionRequiredCallback(ref OnClientActionRequiredCallbackInfo data);
}
