﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020006D9 RID: 1753
	public struct AddNotifyPeerAuthStatusChangedOptions
	{
	}
}
