﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020006CF RID: 1743
	public struct AddExternalIntegrityCatalogOptions
	{
		// Token: 0x17000D89 RID: 3465
		// (get) Token: 0x06002D48 RID: 11592 RVA: 0x00042E1A File Offset: 0x0004101A
		// (set) Token: 0x06002D49 RID: 11593 RVA: 0x00042E22 File Offset: 0x00041022
		public Utf8String PathToBinFile { get; set; }
	}
}
