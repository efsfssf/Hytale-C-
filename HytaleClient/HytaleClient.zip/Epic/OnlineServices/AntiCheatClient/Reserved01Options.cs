﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020006FC RID: 1788
	public struct Reserved01Options
	{
	}
}
