﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x02000700 RID: 1792
	public struct UnregisterPeerOptions
	{
		// Token: 0x17000DBB RID: 3515
		// (get) Token: 0x06002E18 RID: 11800 RVA: 0x0004406A File Offset: 0x0004226A
		// (set) Token: 0x06002E19 RID: 11801 RVA: 0x00044072 File Offset: 0x00042272
		public IntPtr PeerHandle { get; set; }
	}
}
