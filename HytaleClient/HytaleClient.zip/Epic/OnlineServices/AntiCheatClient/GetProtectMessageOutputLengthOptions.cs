﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020006E2 RID: 1762
	public struct GetProtectMessageOutputLengthOptions
	{
		// Token: 0x17000D8F RID: 3471
		// (get) Token: 0x06002D86 RID: 11654 RVA: 0x00043728 File Offset: 0x00041928
		// (set) Token: 0x06002D87 RID: 11655 RVA: 0x00043730 File Offset: 0x00041930
		public uint DataLengthBytes { get; set; }
	}
}
