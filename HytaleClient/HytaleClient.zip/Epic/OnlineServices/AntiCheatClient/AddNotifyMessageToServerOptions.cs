﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020006D5 RID: 1749
	public struct AddNotifyMessageToServerOptions
	{
	}
}
