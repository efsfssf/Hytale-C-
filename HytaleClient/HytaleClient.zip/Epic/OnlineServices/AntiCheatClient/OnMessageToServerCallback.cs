﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020006EA RID: 1770
	// (Invoke) Token: 0x06002DB0 RID: 11696
	public delegate void OnMessageToServerCallback(ref OnMessageToServerCallbackInfo data);
}
