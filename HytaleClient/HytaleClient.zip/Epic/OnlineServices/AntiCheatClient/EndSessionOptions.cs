﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020006E0 RID: 1760
	public struct EndSessionOptions
	{
	}
}
