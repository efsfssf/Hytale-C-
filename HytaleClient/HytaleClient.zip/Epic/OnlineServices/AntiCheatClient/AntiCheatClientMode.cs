﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020006DC RID: 1756
	public enum AntiCheatClientMode
	{
		// Token: 0x0400140C RID: 5132
		Invalid,
		// Token: 0x0400140D RID: 5133
		ClientServer,
		// Token: 0x0400140E RID: 5134
		PeerToPeer
	}
}
