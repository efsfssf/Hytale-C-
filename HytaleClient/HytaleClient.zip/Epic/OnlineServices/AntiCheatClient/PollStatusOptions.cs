﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020006F2 RID: 1778
	public struct PollStatusOptions
	{
		// Token: 0x17000D9D RID: 3485
		// (get) Token: 0x06002DD6 RID: 11734 RVA: 0x00043AD5 File Offset: 0x00041CD5
		// (set) Token: 0x06002DD7 RID: 11735 RVA: 0x00043ADD File Offset: 0x00041CDD
		public uint OutMessageLength { get; set; }
	}
}
