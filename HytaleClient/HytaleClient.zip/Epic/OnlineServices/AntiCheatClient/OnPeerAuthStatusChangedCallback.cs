﻿using System;
using Epic.OnlineServices.AntiCheatCommon;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020006F0 RID: 1776
	// (Invoke) Token: 0x06002DCF RID: 11727
	public delegate void OnPeerAuthStatusChangedCallback(ref OnClientAuthStatusChangedCallbackInfo data);
}
