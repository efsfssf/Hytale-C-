﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020006D7 RID: 1751
	public struct AddNotifyPeerActionRequiredOptions
	{
	}
}
