﻿using System;

namespace Epic.OnlineServices
{
	// Token: 0x02000006 RID: 6
	internal class AllocationException : Exception
	{
		// Token: 0x0600007B RID: 123 RVA: 0x00003FBB File Offset: 0x000021BB
		public AllocationException(string message) : base(message)
		{
		}
	}
}
