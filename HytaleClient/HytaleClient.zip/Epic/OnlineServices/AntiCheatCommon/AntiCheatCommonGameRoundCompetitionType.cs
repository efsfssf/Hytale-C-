﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x0200069D RID: 1693
	public enum AntiCheatCommonGameRoundCompetitionType
	{
		// Token: 0x040012F8 RID: 4856
		None,
		// Token: 0x040012F9 RID: 4857
		Casual,
		// Token: 0x040012FA RID: 4858
		Ranked,
		// Token: 0x040012FB RID: 4859
		Competitive
	}
}
