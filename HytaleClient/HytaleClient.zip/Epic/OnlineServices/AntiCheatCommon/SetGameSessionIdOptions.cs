﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x020006CB RID: 1739
	public struct SetGameSessionIdOptions
	{
		// Token: 0x17000D81 RID: 3457
		// (get) Token: 0x06002D31 RID: 11569 RVA: 0x00042C3B File Offset: 0x00040E3B
		// (set) Token: 0x06002D32 RID: 11570 RVA: 0x00042C43 File Offset: 0x00040E43
		public Utf8String GameSessionId { get; set; }
	}
}
