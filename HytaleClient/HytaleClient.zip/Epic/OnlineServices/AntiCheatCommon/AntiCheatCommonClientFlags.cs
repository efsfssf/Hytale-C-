﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x02000697 RID: 1687
	[Flags]
	public enum AntiCheatCommonClientFlags
	{
		// Token: 0x040012D3 RID: 4819
		None = 0,
		// Token: 0x040012D4 RID: 4820
		Admin = 1
	}
}
