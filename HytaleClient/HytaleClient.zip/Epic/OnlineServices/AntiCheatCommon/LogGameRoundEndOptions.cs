﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x020006A9 RID: 1705
	public struct LogGameRoundEndOptions
	{
		// Token: 0x17000CEC RID: 3308
		// (get) Token: 0x06002BFA RID: 11258 RVA: 0x00040FF6 File Offset: 0x0003F1F6
		// (set) Token: 0x06002BFB RID: 11259 RVA: 0x00040FFE File Offset: 0x0003F1FE
		public uint WinningTeamId { get; set; }
	}
}
