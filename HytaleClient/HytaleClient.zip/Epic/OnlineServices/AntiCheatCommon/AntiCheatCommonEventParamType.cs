﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x0200069B RID: 1691
	public enum AntiCheatCommonEventParamType
	{
		// Token: 0x040012E9 RID: 4841
		Invalid,
		// Token: 0x040012EA RID: 4842
		ClientHandle,
		// Token: 0x040012EB RID: 4843
		String,
		// Token: 0x040012EC RID: 4844
		UInt32,
		// Token: 0x040012ED RID: 4845
		Int32,
		// Token: 0x040012EE RID: 4846
		UInt64,
		// Token: 0x040012EF RID: 4847
		Int64,
		// Token: 0x040012F0 RID: 4848
		Vector3f,
		// Token: 0x040012F1 RID: 4849
		Quat,
		// Token: 0x040012F2 RID: 4850
		Float
	}
}
