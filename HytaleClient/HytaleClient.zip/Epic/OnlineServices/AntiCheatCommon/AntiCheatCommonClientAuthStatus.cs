﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x02000696 RID: 1686
	public enum AntiCheatCommonClientAuthStatus
	{
		// Token: 0x040012CF RID: 4815
		Invalid,
		// Token: 0x040012D0 RID: 4816
		LocalAuthComplete,
		// Token: 0x040012D1 RID: 4817
		RemoteAuthComplete
	}
}
