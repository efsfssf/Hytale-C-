﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x02000698 RID: 1688
	public enum AntiCheatCommonClientInput
	{
		// Token: 0x040012D6 RID: 4822
		Unknown,
		// Token: 0x040012D7 RID: 4823
		MouseKeyboard,
		// Token: 0x040012D8 RID: 4824
		Gamepad,
		// Token: 0x040012D9 RID: 4825
		TouchInput
	}
}
