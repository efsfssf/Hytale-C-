﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x020006A1 RID: 1697
	public enum AntiCheatCommonPlayerTakeDamageSource
	{
		// Token: 0x0400131E RID: 4894
		None,
		// Token: 0x0400131F RID: 4895
		Player,
		// Token: 0x04001320 RID: 4896
		NonPlayerCharacter,
		// Token: 0x04001321 RID: 4897
		World
	}
}
