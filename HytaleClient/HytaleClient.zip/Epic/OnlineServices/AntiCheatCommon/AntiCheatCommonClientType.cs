﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x0200069A RID: 1690
	public enum AntiCheatCommonClientType
	{
		// Token: 0x040012E5 RID: 4837
		ProtectedClient,
		// Token: 0x040012E6 RID: 4838
		UnprotectedClient,
		// Token: 0x040012E7 RID: 4839
		AIBot
	}
}
