﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x02000694 RID: 1684
	public enum AntiCheatCommonClientAction
	{
		// Token: 0x040012C0 RID: 4800
		Invalid,
		// Token: 0x040012C1 RID: 4801
		RemovePlayer
	}
}
