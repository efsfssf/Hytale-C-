﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x020006AD RID: 1709
	public struct LogPlayerDespawnOptions
	{
		// Token: 0x17000CF8 RID: 3320
		// (get) Token: 0x06002C12 RID: 11282 RVA: 0x00041205 File Offset: 0x0003F405
		// (set) Token: 0x06002C13 RID: 11283 RVA: 0x0004120D File Offset: 0x0003F40D
		public IntPtr DespawnedPlayerHandle { get; set; }
	}
}
