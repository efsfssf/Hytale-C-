﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x02000699 RID: 1689
	public enum AntiCheatCommonClientPlatform
	{
		// Token: 0x040012DB RID: 4827
		Unknown,
		// Token: 0x040012DC RID: 4828
		Windows,
		// Token: 0x040012DD RID: 4829
		Mac,
		// Token: 0x040012DE RID: 4830
		Linux,
		// Token: 0x040012DF RID: 4831
		Xbox,
		// Token: 0x040012E0 RID: 4832
		PlayStation,
		// Token: 0x040012E1 RID: 4833
		Nintendo,
		// Token: 0x040012E2 RID: 4834
		iOS,
		// Token: 0x040012E3 RID: 4835
		Android
	}
}
