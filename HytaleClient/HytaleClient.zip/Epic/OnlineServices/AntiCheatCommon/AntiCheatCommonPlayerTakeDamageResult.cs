﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x020006A0 RID: 1696
	public enum AntiCheatCommonPlayerTakeDamageResult
	{
		// Token: 0x04001317 RID: 4887
		None,
		// Token: 0x04001318 RID: 4888
		DownedDEPRECATED,
		// Token: 0x04001319 RID: 4889
		EliminatedDEPRECATED,
		// Token: 0x0400131A RID: 4890
		NormalToDowned,
		// Token: 0x0400131B RID: 4891
		NormalToEliminated,
		// Token: 0x0400131C RID: 4892
		DownedToEliminated
	}
}
