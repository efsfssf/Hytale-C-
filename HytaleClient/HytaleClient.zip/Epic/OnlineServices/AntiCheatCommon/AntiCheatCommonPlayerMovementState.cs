﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x0200069F RID: 1695
	public enum AntiCheatCommonPlayerMovementState
	{
		// Token: 0x0400130E RID: 4878
		None,
		// Token: 0x0400130F RID: 4879
		Crouching,
		// Token: 0x04001310 RID: 4880
		Prone,
		// Token: 0x04001311 RID: 4881
		Mounted,
		// Token: 0x04001312 RID: 4882
		Swimming,
		// Token: 0x04001313 RID: 4883
		Falling,
		// Token: 0x04001314 RID: 4884
		Flying,
		// Token: 0x04001315 RID: 4885
		OnLadder
	}
}
