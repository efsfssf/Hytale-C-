﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x020006BB RID: 1723
	public struct LogPlayerUseWeaponOptions
	{
		// Token: 0x17000D4C RID: 3404
		// (get) Token: 0x06002CAD RID: 11437 RVA: 0x00042038 File Offset: 0x00040238
		// (set) Token: 0x06002CAE RID: 11438 RVA: 0x00042040 File Offset: 0x00040240
		public LogPlayerUseWeaponData? UseWeaponData { get; set; }
	}
}
