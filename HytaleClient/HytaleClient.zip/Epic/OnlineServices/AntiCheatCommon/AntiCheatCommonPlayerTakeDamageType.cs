﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x020006A2 RID: 1698
	public enum AntiCheatCommonPlayerTakeDamageType
	{
		// Token: 0x04001323 RID: 4899
		None,
		// Token: 0x04001324 RID: 4900
		PointDamage,
		// Token: 0x04001325 RID: 4901
		RadialDamage,
		// Token: 0x04001326 RID: 4902
		DamageOverTime
	}
}
