﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x0200069C RID: 1692
	public enum AntiCheatCommonEventType
	{
		// Token: 0x040012F4 RID: 4852
		Invalid,
		// Token: 0x040012F5 RID: 4853
		GameEvent,
		// Token: 0x040012F6 RID: 4854
		PlayerEvent
	}
}
