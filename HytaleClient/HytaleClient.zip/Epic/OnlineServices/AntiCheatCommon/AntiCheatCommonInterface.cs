﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x0200069E RID: 1694
	public sealed class AntiCheatCommonInterface
	{
		// Token: 0x040012FC RID: 4860
		public const int LogeventApiLatest = 1;

		// Token: 0x040012FD RID: 4861
		public const int LogeventStringMaxLength = 39;

		// Token: 0x040012FE RID: 4862
		public const int LoggameroundendApiLatest = 1;

		// Token: 0x040012FF RID: 4863
		public const int LoggameroundstartApiLatest = 2;

		// Token: 0x04001300 RID: 4864
		public const int LogplayerdespawnApiLatest = 1;

		// Token: 0x04001301 RID: 4865
		public const int LogplayerreviveApiLatest = 1;

		// Token: 0x04001302 RID: 4866
		public const int LogplayerspawnApiLatest = 1;

		// Token: 0x04001303 RID: 4867
		public const int LogplayertakedamageApiLatest = 4;

		// Token: 0x04001304 RID: 4868
		public const int LogplayertickApiLatest = 3;

		// Token: 0x04001305 RID: 4869
		public const int LogplayeruseabilityApiLatest = 1;

		// Token: 0x04001306 RID: 4870
		public const int LogplayeruseweaponApiLatest = 2;

		// Token: 0x04001307 RID: 4871
		public const int LogplayeruseweaponWeaponnameMaxLength = 16;

		// Token: 0x04001308 RID: 4872
		public const int RegistereventApiLatest = 1;

		// Token: 0x04001309 RID: 4873
		public const int RegistereventCustomeventbase = 268435456;

		// Token: 0x0400130A RID: 4874
		public const int RegistereventMaxParamdefscount = 12;

		// Token: 0x0400130B RID: 4875
		public const int SetclientdetailsApiLatest = 1;

		// Token: 0x0400130C RID: 4876
		public const int SetgamesessionidApiLatest = 1;
	}
}
