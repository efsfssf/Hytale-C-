﻿using System;

namespace Epic.OnlineServices.AntiCheatServer
{
	// Token: 0x02000675 RID: 1653
	public struct AddNotifyClientActionRequiredOptions
	{
	}
}
