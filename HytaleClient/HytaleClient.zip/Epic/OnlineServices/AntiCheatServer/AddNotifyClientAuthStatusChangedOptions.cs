﻿using System;

namespace Epic.OnlineServices.AntiCheatServer
{
	// Token: 0x02000677 RID: 1655
	public struct AddNotifyClientAuthStatusChangedOptions
	{
	}
}
