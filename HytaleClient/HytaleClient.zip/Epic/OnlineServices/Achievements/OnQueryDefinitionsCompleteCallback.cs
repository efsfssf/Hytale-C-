﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200074A RID: 1866
	// (Invoke) Token: 0x06003077 RID: 12407
	public delegate void OnQueryDefinitionsCompleteCallback(ref OnQueryDefinitionsCompleteCallbackInfo data);
}
