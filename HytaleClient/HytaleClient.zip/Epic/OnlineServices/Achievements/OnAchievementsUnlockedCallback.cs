﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000742 RID: 1858
	// (Invoke) Token: 0x0600303D RID: 12349
	public delegate void OnAchievementsUnlockedCallback(ref OnAchievementsUnlockedCallbackInfo data);
}
