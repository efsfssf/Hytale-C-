﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200072E RID: 1838
	public struct CopyAchievementDefinitionV2ByIndexOptions
	{
		// Token: 0x17000E4B RID: 3659
		// (get) Token: 0x06002F9F RID: 12191 RVA: 0x00046C31 File Offset: 0x00044E31
		// (set) Token: 0x06002FA0 RID: 12192 RVA: 0x00046C39 File Offset: 0x00044E39
		public uint AchievementIndex { get; set; }
	}
}
