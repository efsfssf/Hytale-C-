﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200073C RID: 1852
	public struct GetAchievementDefinitionCountOptions
	{
	}
}
