﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200073E RID: 1854
	public struct GetPlayerAchievementCountOptions
	{
		// Token: 0x17000E8B RID: 3723
		// (get) Token: 0x06003030 RID: 12336 RVA: 0x00047BDC File Offset: 0x00045DDC
		// (set) Token: 0x06003031 RID: 12337 RVA: 0x00047BE4 File Offset: 0x00045DE4
		public ProductUserId UserId { get; set; }
	}
}
