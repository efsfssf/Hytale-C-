﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200072C RID: 1836
	public struct CopyAchievementDefinitionV2ByAchievementIdOptions
	{
		// Token: 0x17000E49 RID: 3657
		// (get) Token: 0x06002F99 RID: 12185 RVA: 0x00046BB1 File Offset: 0x00044DB1
		// (set) Token: 0x06002F9A RID: 12186 RVA: 0x00046BB9 File Offset: 0x00044DB9
		public Utf8String AchievementId { get; set; }
	}
}
