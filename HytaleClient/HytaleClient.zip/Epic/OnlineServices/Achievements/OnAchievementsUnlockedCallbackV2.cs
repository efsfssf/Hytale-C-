﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000746 RID: 1862
	// (Invoke) Token: 0x06003058 RID: 12376
	public delegate void OnAchievementsUnlockedCallbackV2(ref OnAchievementsUnlockedCallbackV2Info data);
}
