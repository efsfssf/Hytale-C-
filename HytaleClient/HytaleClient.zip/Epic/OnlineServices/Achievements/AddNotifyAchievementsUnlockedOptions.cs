﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000724 RID: 1828
	public struct AddNotifyAchievementsUnlockedOptions
	{
	}
}
