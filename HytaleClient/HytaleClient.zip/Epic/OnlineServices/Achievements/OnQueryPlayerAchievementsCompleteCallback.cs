﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200074E RID: 1870
	// (Invoke) Token: 0x0600308E RID: 12430
	public delegate void OnQueryPlayerAchievementsCompleteCallback(ref OnQueryPlayerAchievementsCompleteCallbackInfo data);
}
