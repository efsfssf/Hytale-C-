﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000726 RID: 1830
	public struct AddNotifyAchievementsUnlockedV2Options
	{
	}
}
