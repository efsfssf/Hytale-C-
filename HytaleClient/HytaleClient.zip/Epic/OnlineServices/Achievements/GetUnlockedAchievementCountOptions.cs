﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000740 RID: 1856
	public struct GetUnlockedAchievementCountOptions
	{
		// Token: 0x17000E8D RID: 3725
		// (get) Token: 0x06003036 RID: 12342 RVA: 0x00047C59 File Offset: 0x00045E59
		// (set) Token: 0x06003037 RID: 12343 RVA: 0x00047C61 File Offset: 0x00045E61
		public ProductUserId UserId { get; set; }
	}
}
