﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000752 RID: 1874
	// (Invoke) Token: 0x060030AD RID: 12461
	public delegate void OnUnlockAchievementsCompleteCallback(ref OnUnlockAchievementsCompleteCallbackInfo data);
}
