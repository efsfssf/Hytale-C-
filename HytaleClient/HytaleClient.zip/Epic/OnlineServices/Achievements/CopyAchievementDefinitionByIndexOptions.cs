﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200072A RID: 1834
	public struct CopyAchievementDefinitionByIndexOptions
	{
		// Token: 0x17000E47 RID: 3655
		// (get) Token: 0x06002F93 RID: 12179 RVA: 0x00046B45 File Offset: 0x00044D45
		// (set) Token: 0x06002F94 RID: 12180 RVA: 0x00046B4D File Offset: 0x00044D4D
		public uint AchievementIndex { get; set; }
	}
}
