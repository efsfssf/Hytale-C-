﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000728 RID: 1832
	public struct CopyAchievementDefinitionByAchievementIdOptions
	{
		// Token: 0x17000E45 RID: 3653
		// (get) Token: 0x06002F8D RID: 12173 RVA: 0x00046AC8 File Offset: 0x00044CC8
		// (set) Token: 0x06002F8E RID: 12174 RVA: 0x00046AD0 File Offset: 0x00044CD0
		public Utf8String AchievementId { get; set; }
	}
}
