﻿using System;

namespace HytaleClient.Data.Items
{
	// Token: 0x02000AED RID: 2797
	public class ClientCraftingCategory
	{
		// Token: 0x0400366E RID: 13934
		public string Id;

		// Token: 0x0400366F RID: 13935
		public string Icon;

		// Token: 0x04003670 RID: 13936
		public int Order;

		// Token: 0x04003671 RID: 13937
		public ClientCraftingItemCategory[] ItemCategories;
	}
}
