﻿using System;

namespace HytaleClient.Data.Items
{
	// Token: 0x02000AEE RID: 2798
	public class ClientCraftingItemCategory
	{
		// Token: 0x04003672 RID: 13938
		public string Id;

		// Token: 0x04003673 RID: 13939
		public string Icon;

		// Token: 0x04003674 RID: 13940
		public string Diagram;

		// Token: 0x04003675 RID: 13941
		public int Slots;

		// Token: 0x04003676 RID: 13942
		public bool SpecialSlot;
	}
}
