﻿using System;

namespace HytaleClient.Data.Map.Chunk
{
	// Token: 0x02000AE5 RID: 2789
	public enum BlockSetResult
	{
		// Token: 0x04003660 RID: 13920
		BLOCK_ADDED_OR_REMOVED,
		// Token: 0x04003661 RID: 13921
		BLOCK_CHANGED,
		// Token: 0x04003662 RID: 13922
		BLOCK_UNCHANGED,
		// Token: 0x04003663 RID: 13923
		REQUIRES_PROMOTE
	}
}
