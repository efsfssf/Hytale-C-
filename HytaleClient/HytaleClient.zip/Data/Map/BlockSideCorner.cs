﻿using System;

namespace HytaleClient.Data.Map
{
	// Token: 0x02000ADD RID: 2781
	internal static class BlockSideCorner
	{
		// Token: 0x040035EA RID: 13802
		public const int TopRight = 0;

		// Token: 0x040035EB RID: 13803
		public const int TopLeft = 1;

		// Token: 0x040035EC RID: 13804
		public const int BottomLeft = 2;

		// Token: 0x040035ED RID: 13805
		public const int BottomRight = 3;

		// Token: 0x040035EE RID: 13806
		public const int Count = 4;
	}
}
