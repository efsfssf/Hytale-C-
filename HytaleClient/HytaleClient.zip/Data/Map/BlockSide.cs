﻿using System;

namespace HytaleClient.Data.Map
{
	// Token: 0x02000ADC RID: 2780
	internal static class BlockSide
	{
		// Token: 0x040035E2 RID: 13794
		public const int Top = 0;

		// Token: 0x040035E3 RID: 13795
		public const int Bottom = 1;

		// Token: 0x040035E4 RID: 13796
		public const int Left = 2;

		// Token: 0x040035E5 RID: 13797
		public const int Right = 3;

		// Token: 0x040035E6 RID: 13798
		public const int Front = 4;

		// Token: 0x040035E7 RID: 13799
		public const int Back = 5;

		// Token: 0x040035E8 RID: 13800
		public const int Count = 6;

		// Token: 0x040035E9 RID: 13801
		public const int UpFlag = 1;
	}
}
