﻿using System;

namespace HytaleClient.Data.Map
{
	// Token: 0x02000AE1 RID: 2785
	internal static class LightChannel
	{
		// Token: 0x04003646 RID: 13894
		public const int Red = 0;

		// Token: 0x04003647 RID: 13895
		public const int Green = 1;

		// Token: 0x04003648 RID: 13896
		public const int Blue = 2;

		// Token: 0x04003649 RID: 13897
		public const int Sunlight = 3;

		// Token: 0x0400364A RID: 13898
		public const int Count = 4;
	}
}
