﻿using System;
using HytaleClient.InGame.Modules.Entities;
using HytaleClient.Math;

namespace HytaleClient.Data.ClientInteraction.Selector
{
	// Token: 0x02000B22 RID: 2850
	// (Invoke) Token: 0x060058E6 RID: 22758
	internal delegate void EntityHitConsumer(Entity entity, Vector4 hit);
}
