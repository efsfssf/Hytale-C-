﻿using System;
using HytaleClient.InGame;

namespace HytaleClient.Data.ClientInteraction.Selector
{
	// Token: 0x02000B1B RID: 2843
	// (Invoke) Token: 0x060058D1 RID: 22737
	internal delegate bool LineOfSightProvider(GameInstance gameInstance, float fromX, float fromY, float fromZ, float toX, float toY, float toZ);
}
