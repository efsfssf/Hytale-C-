﻿using System;

namespace HytaleClient.Data.BlockyModels
{
	// Token: 0x02000B70 RID: 2928
	public struct AxisMirror
	{
		// Token: 0x04003841 RID: 14401
		public bool X;

		// Token: 0x04003842 RID: 14402
		public bool Y;
	}
}
