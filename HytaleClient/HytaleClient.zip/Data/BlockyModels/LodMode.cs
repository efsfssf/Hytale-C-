﻿using System;

namespace HytaleClient.Data.BlockyModels
{
	// Token: 0x02000B72 RID: 2930
	public enum LodMode
	{
		// Token: 0x04003845 RID: 14405
		Off,
		// Token: 0x04003846 RID: 14406
		Auto,
		// Token: 0x04003847 RID: 14407
		Billboard,
		// Token: 0x04003848 RID: 14408
		Disappear
	}
}
