﻿using System;

namespace HytaleClient.Data.BlockyModels
{
	// Token: 0x02000B6B RID: 2923
	public struct BlockyModelJson
	{
		// Token: 0x0400382C RID: 14380
		public string Lod;

		// Token: 0x0400382D RID: 14381
		public BlockyModelNodeJson[] Nodes;
	}
}
