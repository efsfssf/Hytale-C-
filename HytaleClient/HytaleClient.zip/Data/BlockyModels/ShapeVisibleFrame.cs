﻿using System;

namespace HytaleClient.Data.BlockyModels
{
	// Token: 0x02000B65 RID: 2917
	public struct ShapeVisibleFrame
	{
		// Token: 0x04003805 RID: 14341
		public int Time;

		// Token: 0x04003806 RID: 14342
		public bool Delta;
	}
}
