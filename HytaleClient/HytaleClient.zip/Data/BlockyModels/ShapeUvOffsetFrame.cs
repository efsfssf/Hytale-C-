﻿using System;
using HytaleClient.Math;

namespace HytaleClient.Data.BlockyModels
{
	// Token: 0x02000B66 RID: 2918
	public struct ShapeUvOffsetFrame
	{
		// Token: 0x04003807 RID: 14343
		public int Time;

		// Token: 0x04003808 RID: 14344
		public Point Delta;
	}
}
