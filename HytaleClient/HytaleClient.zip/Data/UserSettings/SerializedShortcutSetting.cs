﻿using System;

namespace HytaleClient.Data.UserSettings
{
	// Token: 0x02000ADA RID: 2778
	internal struct SerializedShortcutSetting
	{
		// Token: 0x040035DD RID: 13789
		public string name;

		// Token: 0x040035DE RID: 13790
		public string command;
	}
}
