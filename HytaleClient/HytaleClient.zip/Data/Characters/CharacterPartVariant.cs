﻿using System;
using System.Collections.Generic;

namespace HytaleClient.Data.Characters
{
	// Token: 0x02000B59 RID: 2905
	public class CharacterPartVariant
	{
		// Token: 0x040037C3 RID: 14275
		public string Model;

		// Token: 0x040037C4 RID: 14276
		public Dictionary<string, CharacterPartTexture> Textures;

		// Token: 0x040037C5 RID: 14277
		public string GreyscaleTexture;
	}
}
