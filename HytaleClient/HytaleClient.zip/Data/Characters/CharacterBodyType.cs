﻿using System;

namespace HytaleClient.Data.Characters
{
	// Token: 0x02000B50 RID: 2896
	public enum CharacterBodyType
	{
		// Token: 0x0400377D RID: 14205
		None,
		// Token: 0x0400377E RID: 14206
		Masculine,
		// Token: 0x0400377F RID: 14207
		Feminine
	}
}
