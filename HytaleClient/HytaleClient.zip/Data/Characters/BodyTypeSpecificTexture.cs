﻿using System;

namespace HytaleClient.Data.Characters
{
	// Token: 0x02000B4E RID: 2894
	public class BodyTypeSpecificTexture
	{
		// Token: 0x04003776 RID: 14198
		public string Masculine;

		// Token: 0x04003777 RID: 14199
		public string Feminine;
	}
}
