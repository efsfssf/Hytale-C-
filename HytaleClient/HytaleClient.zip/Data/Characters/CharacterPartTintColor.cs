﻿using System;

namespace HytaleClient.Data.Characters
{
	// Token: 0x02000B58 RID: 2904
	public class CharacterPartTintColor
	{
		// Token: 0x040037BF RID: 14271
		public string Id;

		// Token: 0x040037C0 RID: 14272
		public string[] BaseColor;

		// Token: 0x040037C1 RID: 14273
		public string Texture;

		// Token: 0x040037C2 RID: 14274
		public byte GradientId;
	}
}
