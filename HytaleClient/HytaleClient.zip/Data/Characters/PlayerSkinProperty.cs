﻿using System;

namespace HytaleClient.Data.Characters
{
	// Token: 0x02000B5C RID: 2908
	public enum PlayerSkinProperty
	{
		// Token: 0x040037DB RID: 14299
		BodyType,
		// Token: 0x040037DC RID: 14300
		SkinTone,
		// Token: 0x040037DD RID: 14301
		Haircut,
		// Token: 0x040037DE RID: 14302
		FacialHair,
		// Token: 0x040037DF RID: 14303
		Eyebrows,
		// Token: 0x040037E0 RID: 14304
		Eyes,
		// Token: 0x040037E1 RID: 14305
		Face,
		// Token: 0x040037E2 RID: 14306
		Pants,
		// Token: 0x040037E3 RID: 14307
		Overpants,
		// Token: 0x040037E4 RID: 14308
		Undertop,
		// Token: 0x040037E5 RID: 14309
		Overtop,
		// Token: 0x040037E6 RID: 14310
		Shoes,
		// Token: 0x040037E7 RID: 14311
		HeadAccessory,
		// Token: 0x040037E8 RID: 14312
		FaceAccessory,
		// Token: 0x040037E9 RID: 14313
		EarAccessory,
		// Token: 0x040037EA RID: 14314
		SkinFeature,
		// Token: 0x040037EB RID: 14315
		Gloves
	}
}
