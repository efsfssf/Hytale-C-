﻿using System;
using System.Collections.Generic;

namespace HytaleClient.Data.Characters
{
	// Token: 0x02000B54 RID: 2900
	public class CharacterPartGradientSet
	{
		// Token: 0x0400378C RID: 14220
		public string Id;

		// Token: 0x0400378D RID: 14221
		public Dictionary<string, CharacterPartTintColor> Gradients;
	}
}
