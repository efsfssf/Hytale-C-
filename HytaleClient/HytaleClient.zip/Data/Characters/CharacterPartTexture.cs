﻿using System;

namespace HytaleClient.Data.Characters
{
	// Token: 0x02000B57 RID: 2903
	public class CharacterPartTexture
	{
		// Token: 0x040037BD RID: 14269
		public string Texture;

		// Token: 0x040037BE RID: 14270
		public string[] BaseColor;
	}
}
