﻿using System;

namespace HytaleClient.Data.Characters
{
	// Token: 0x02000B5B RID: 2907
	public class Emote
	{
		// Token: 0x040037D7 RID: 14295
		public string Id;

		// Token: 0x040037D8 RID: 14296
		public string Name;

		// Token: 0x040037D9 RID: 14297
		public string Animation;
	}
}
