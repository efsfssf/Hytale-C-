﻿using System;

namespace HytaleClient.AssetEditor.Interface.Previews
{
	// Token: 0x02000B9B RID: 2971
	public enum CameraType
	{
		// Token: 0x04003966 RID: 14694
		Camera3D,
		// Token: 0x04003967 RID: 14695
		Camera2D
	}
}
