﻿using System;

namespace HytaleClient.AssetEditor.Data
{
	// Token: 0x02000BD8 RID: 3032
	public enum AssetTreeFolder
	{
		// Token: 0x04003B6D RID: 15213
		Server,
		// Token: 0x04003B6E RID: 15214
		Common,
		// Token: 0x04003B6F RID: 15215
		Cosmetics
	}
}
